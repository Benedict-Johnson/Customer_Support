# Policy-Aware Customer Support Agent (LLM + RAG)

## Setup
1) Create an environment and install deps:
```bash
pip install -r requirements.txt
```

2) Set Groq key:
```bash
export GROQ_API_KEY="YOUR_KEY"
```

## Run CLI
```bash
PYTHONPATH=. python scripts/chat_cli.py
```

## Notes
- `data/policies.json` holds the policies.
- SQLite logs are written to `support.db`.
