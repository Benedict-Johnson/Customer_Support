SIMILARITY_THRESHOLD = 0.35   # was 0.50 (too strict)
MARGIN_THRESHOLD = 0.05       # if top1 and top2 are too close → ambiguous → escalate
DB_PATH = "support.db"
