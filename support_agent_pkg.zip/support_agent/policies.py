import json

with open("data/policies.json", "r") as f:
    policies = json.load(f)
