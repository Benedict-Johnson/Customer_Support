import sqlite3
import datetime
import json
from .config import DB_PATH

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS interaction_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT,
        user_text TEXT,
        policy_id TEXT,
        similarity_score REAL,
        escalated INTEGER,
        response_json TEXT
    )
    """)
    conn.commit()
    conn.close()

def write_log(user_text, policy_id, score, escalated, response_obj):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
    INSERT INTO interaction_logs (timestamp, user_text, policy_id, similarity_score, escalated, response_json)
    VALUES (?, ?, ?, ?, ?, ?)
    """, (
        datetime.datetime.now(datetime.UTC).isoformat(),
        user_text,
        policy_id,
        float(score) if score is not None else None,
        1 if escalated else 0,
        json.dumps(response_obj)
    ))
    conn.commit()
    conn.close()

init_db()
